#!/bin/sh
export RT='/home/omsdev/devtoolkit/devtoolkit_docker/runtime'

date >> ~/tester/logs/SterlingTester.log
{
. ${RT}/bin/tmp.sh 
} >> ~/tester/logs/SterlingTester.log

allLog='Y'
promptUser='Y'
promptPwd='Y'
for arg in $@
do
  #echo "$arg"
  if [[ "$arg" ==  '-nodebug' ]]
  then
     allLog='N'
  elif [[ "$arg" =~ (-u=).* ]]
  then
     promptUser='N'
     user=`echo $arg | sed 's/-u=//'`
  elif [[ "$arg" =~ (-p=).* ]]
  then
     promptPwd='N'
     password=`echo $arg | sed 's/-p=//'`
  fi
done


USE_AGENT_JAVA=1
export USE_JAVA_AGENT

 	AGENT_JAVA_OPTS="-Dvendor=shell -DvendorFile=${RT}/properties/servers.properties -DCACHE_PS=true -DDISABLE_DS_EXTENSIONS=Y -Dyfs.logall=$allLog"
export AGENT_JAVA_OPTS

if [[ "$promptUser" == 'Y' ]]
then
  echo -n 'OMS User: '
  read user
fi
if [[ "$promptPwd" == 'Y' ]]
then
  echo -n 'OMS Password: '
  read -s password
  echo
fi

   ${AGENT_JAVA_SERVER} -classpath ${RT}/jar/bootstrapper.jar ${AGENT_JAVA_OPTS} com.sterlingcommerce.woodstock.noapp.NoAppLoader  -f ./SterlingTester.cfg -class tester.SterlingTester -invokeargs $@ -u=$user -p=$password   
