#!/bin/sh
export RT='/home/omsdev/devtoolkit/devtoolkit_docker/runtime'

date >> ~/tester/logs/SterlingTestServer.log
{
. ${RT}/bin/tmp.sh 
} >> ~/tester/logs/SterlingTestServer.log

allLog='Y'
for arg in $@
do
  #echo "$arg"
  if [[ "$arg" ==  '-nodebug' ]]
  then
     allLog='N'
  fi
done


USE_AGENT_JAVA=1
export USE_JAVA_AGENT

 	AGENT_JAVA_OPTS="-Dvendor=shell -DvendorFile=${RT}/properties/servers.properties -DCACHE_PS=true -DDISABLE_DS_EXTENSIONS=Y -Dyfs.logall=$allLog"
export AGENT_JAVA_OPTS

   ${AGENT_JAVA_SERVER} -classpath ${RT}/jar/bootstrapper.jar ${AGENT_JAVA_OPTS} com.sterlingcommerce.woodstock.noapp.NoAppLoader  -f ./SterlingTester.cfg -class util.SterlingTestServer -invokeargs $@ 
